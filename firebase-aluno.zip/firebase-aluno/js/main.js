const banco_dados = firebase.firestore()
let tasks = []

function btnTask() {
    const btn_addTask = document.getElementById('btn-addTask')
    if(btn_addTask){
        btn_addTask.addEventListener('click', addTask)
    }
}

function getUser() {
    firebase.auth().onAuthStateChanged((user) => {
        if (user) {   
            let nome_email = user.email
            let nome = nome_email.substring(0, nome_email.indexOf("@"))
            let userLabel = document.getElementById("navbarDropdown")
            userLabel.innerHTML = nome
        } else {
            swal
                .fire({
                    icon: "warning",
                    title: "Redirecionando para a tela de autenticação",
                })
                .then(() => {
                    setTimeout( () => {
                        window.location.replace("login.html")
                }, 890)
            })
        }
    })
}

function createDelButton(task) {
    const newButton = document.createElement('button')
    newButton.setAttribute('class','btn btn-info text-dark p-1 px-4')
    newButton.appendChild(document.createTextNode('Excluir'))
    newButton.setAttribute('onclick', `deleteTask("${task.id}")`)
    return newButton
}

function renderTasks() {
    let itemList = document.getElementById('list-tasks')
    if(itemList){
        itemList.innerHTML = ""
        for (let task of tasks) {
            const newItem = document.createElement('li')
            newItem.setAttribute('class','list-group-item d-flex justify-content-between'
            )
            newItem.appendChild(document.createTextNode(task.title))
            newItem.appendChild(createDelButton(task))
            itemList.appendChild(newItem)
        }
    }
}

async function readTasks() {
    tasks = []
    const logTasks = await banco_dados.collection("tasks").get()
    for (doc of logTasks.docs) {
        tasks.push({
            id:doc.id,
            title: doc.data().title,
        })
    }
    renderTasks()
}

async function addTask(){
    const title = document.getElementById('newItem').value
    if (title && title != ' '){
        const itemList = document.getElementById('list-tasks')
        const spinnerLoad = document.createElement('li')
        spinnerLoad.setAttribute("class","spinner-border spinner-border spinner-border-xl text-info mx-auto my-3")
        itemList.appendChild(spinnerLoad)
        await banco_dados.collection("tasks").add({
            title: title,
        })
        readTasks()
    } else {
        swal.fire({
            icon: "error",
            title: "Você não digitu uma tarefa",
        })
    }
}
async function deleteTask(id){
    await banco_dados.collection('tasks').doc(id).delete()
    readTasks()
}

window.onload = function () {
    getUser()
    readTasks()
    btnTask()
}
