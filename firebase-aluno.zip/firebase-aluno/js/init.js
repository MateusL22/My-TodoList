// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyAY9qpmi7hUwSHV6Y7GSafvT6PVz7pt6hg",
    authDomain: "buscaboot-login.firebaseapp.com",
    databaseURL: "https://buscaboot-login.firebaseio.com",
    projectId: "buscaboot-login",
    storageBucket: "buscaboot-login.appspot.com",
    messagingSenderId: "114782342191",
    appId: "1:114782342191:web:9f89544099c729219dcada"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
