// sistema de hstorico fica FEIO no layout
// erro na calculadora (não escreve os numeros)

function pegaHistorico(){
    return document.querySelector('#value-historico').innerHTML;
}

function escreveHistorico(num){
    document.querySelector('#value-historico').innerHTML=num;
}

function pegaResultado(){
    return document.querySelector('#value-resultado').innerHTML;
}

function escreveResultado(num){
    if(num==''){
        document.querySelector('#value-resultado').innerHTML=num;
    }else{
        document.querySelector('#value-resultado').innerHTML = formataNumero(num)
    }
}

function formataNumero(num){
    if(num=='-'){
        document.querySelector('#value-resultado').innerHTML= '';
    }
    var n = Number(num);
    var value = n.toLocaleString('pt-br');
    return value;

}

function formatacaoReversa(num){
    return Number(num.replace(/,/g,''));
}

var operador = document.getElementsByClassName('operador');
for(var x = 0; x < operador.length; x++){
    operador[x].addEventListener('click', function(){
        if(this.id == 'clear'){
                escreveHistorico('')
                escreveResultado('')
        }else{
            var resultado = pegaResultado();
            var historico = pegaHistorico();
            if(resultado == '' && historico != ''){
                if(isNaN(historico[historico.length-1])){
                    historico = historico.substr(0,historico-length-1);
                }
            }
            if(resultado != '' || historico != ''){
                resultado = resultado == ' ' ? resultado:formatacaoReversa(resultado);
                historico = historico + resultado;
                if(this.id=="="){
                    var resultadoVisor = eval(historico);
                    escreveResultado(resultadoVisor);
                    escreveHistorico('')
                }else{
                    historico = historico + this.id;
                    escreveHistorico(historico);
                    escreveResultado('');
                }
            }
        }
    })
}

var number = document.getElementsByClassName('number');
for(var y = 0; y < number.length; y++ ){
    number[y].addEventListener('click', function(){
        var visor = formatacaoReversa(pegaResultado());
        if(visor != 'NaN'){
            resultado += this.id;
            
        }
    })
    
}

