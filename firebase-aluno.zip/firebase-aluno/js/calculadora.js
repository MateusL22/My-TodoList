//calculadora simples
//function eval não recomendada mudar depois

let visor = document.calc.visor

function inserirNumero(num){
    visor.value += num;
}
function limpa(){
    visor.value = '';
}
function calcula(){
    let resultado = eval(visor.value);
    visor.value = resultado.toLocaleString('pt-BR');
}
