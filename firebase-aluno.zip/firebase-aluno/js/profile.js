const banco_dados = firebase.firestore()
let currentUser = {}
let proflie = false

function getUser() {
    firebase.auth().onAuthStateChanged((user) => {
        if (user) {   
            currentUser.uid = user.uid
            getUserInfo(user.uid)
            let nome_email = user.email
            let nome = nome_email.substring(0, nome_email.indexOf("@"))
            let userLabel = document.getElementById("navbarDropdown")
            userLabel.innerHTML = nome
        } else {
            swal
                .fire({
                    icon: "warning",
                    title: "Redirecionando para a tela de autenticação",
                })
                .then(() => {
                    setTimeout( () => {
                        window.location.replace("login.html")
                }, 1000)
            })
        }
    })
}

async function getUserInfo(uid){
    const logUsers = await banco_dados.collection("profile").where("uid", "==", uid).get()
    let userInfo = document.getElementById('userInfo')
    if (logUsers.docs.length == 0) {
        userInfo.innerHTML = "Perfil Não Registrado"
        userInfo.setAttribute('class', 'text-danger')
    } else {
        userInfo.innerHTML = "Perfil Registrado"
        userInfo.setAttribute('class', 'text-success')
        proflie = true
    }
}

async function saveProflie() {
    const firstName = document.getElementById('firstName').value
    const lastName = document.getElementById('lastName').value
    if (!proflie) {
        await banco_dados.collection("proflie").add({
            uid: currentUser.uid,
            firstName: firstName,
            lastName: lastName,
        })
        getUserInfo()
    }
}

window.onload = function () {
    getUser()
}